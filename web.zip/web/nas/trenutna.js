let firebaseUrl = "https://serije-34d63-default-rtdb.firebaseio.com/";

let serijaId = getParamValue('id');
let serija = {};
let getRequest = new XMLHttpRequest();
let suma=0;

getRequest.onreadystatechange = function(){

  if(this.readyState==4){
    if(this.status==200){
        console.log(serijaId);
      serija = JSON.parse(this.responseText);
      console.log(serija);
      keys=Object.keys(serija);
      values=Object.values(serija);
      ocene=serija.ocene;
      trailer=serija.trailer;
      addImg('slika',serija);

      
      for(let i in keys){
          let key = keys[i];
          let value = values[i];
         
        addTd('serijaInfo',key,value);
      }
     
      suma = ocene.reduce(function(a, b){
        return a + b;
    }, 0);
    
    addTrailer('trailer',serija);

      for(let i in ocene){
        addRating('ocene',i,ocene);
      }
    }else{

      alert('Greska prilikom ucitavanja');
    }
  }

}
getRequest.open('GET',firebaseUrl.concat('/popularno/',serijaId,'.json'));
getRequest.send();

function addTd(tbodyId,serijaKey,value){
    if(serijaKey!="slika" && serijaKey!="ocene" && serijaKey!="trailer"){
        let userTr = document.createElement('tr');
        
        let nameTd = document.createElement('td');
        nameTd.innerText = serijaKey;
        nameTd.setAttribute("style","width:20%");
        nameTd.setAttribute("class","bolder tabela");
        userTr.appendChild(nameTd);

        let nameTd1 = document.createElement('td');
        nameTd1.innerText = value;
        userTr.appendChild(nameTd1);

        let tbody = document.getElementById(tbodyId);
    tbody.appendChild(userTr);
    }
}

    function addImg(tbodyId,serija){
        let picture = document.createElement('img');
        picture.setAttribute("class","serijaslika rounded");
        picture.setAttribute("src",serija.slika);
        let title = document.createElement('h1');
        title.innerText = serija.naziv;
        title.setAttribute("class","serija-title serija-title-banner rounded-bottom h1");

        let tbody = document.getElementById(tbodyId);
        tbody.setAttribute("class"," kartica");
        tbody.appendChild(picture);
        tbody.appendChild(title);

    }
    function addTrailer(tbodyId,serija){
      let trailer = document.createElement('a');
      let tbody = document.getElementById(tbodyId);
      trailer.setAttribute("href",serija.trailer);
      tbody.appendChild(trailer);

  }

   function addRating(tbodyId,i,ocene){
        let j = parseInt(i)+1;
        let progress=parseInt(ocene[i]);

        let div1 = document.createElement('div');
        div1.setAttribute("class","row");

        let div2 = document.createElement('div');
        div2.setAttribute("class","column");

        let div3 = document.createElement('div');
        div3.setAttribute("class","column1");

        let div4 = document.createElement('div');
        div4.setAttribute("class","column");
        div4.innerText=j;

        let div5 = document.createElement('div');
        div5.setAttribute("class","column1");

        let div6 = document.createElement('div');
        div6.setAttribute("class","progress");

        let div7 = document.createElement('div');
        div7.setAttribute("class","progress-bar ");
        div7.setAttribute("style","width:"+ocene[i]*100/suma+"%");
        div7.innerText=ocene[i];

        div6.appendChild(div7);
        div5.appendChild(div6);
        div3.appendChild(div4);
        div3.appendChild(div5);
        div1.appendChild(div2);
        div1.appendChild(div3);



        
        let tbody = document.getElementById(tbodyId);
        tbody.appendChild(div1);

    }
  
  function getParamValue(name) {
    let location = decodeURI(window.location.toString());
    let index = location.indexOf("?") + 1;
    let subs = location.substring(index, location.length);
    let splitted = subs.split("&");

    for (i = 0; i < splitted.length; i++) {
      let s = splitted[i].split("=");
      let pName = s[0];
      let pValue = s[1];
      if (pName == name) {
        return pValue;
      }
    }
  }