let firebaseUrl = "https://serije-34d63-default-rtdb.firebaseio.com/";

let userId = getParamValue('id');
let user = {};
let getRequest = new XMLHttpRequest();

getRequest.onreadystatechange = function(){

  if(this.readyState==4){
    if(this.status==200){
      serije = JSON.parse(this.responseText);
      console.log(serije);
      for(let i in serije){
          let serija = serije[i];
         
        addCard('div1',i,serija);
      }



    }else{
      alert('Greska prilikom ucitavanja');
    }
  }

}
getRequest.open('GET',firebaseUrl.concat('/popularno.json'));
getRequest.send();

function addCard(tbodyId,serijaId,serija){
    let viewBtn = document.createElement('button');
    viewBtn.type='button';
    viewBtn.innerText = 'Detalji';
    viewBtn.setAttribute("class","btn btn-sm btn-outline-secondary")
    viewBtn.setAttribute("style","color:white;background-color:#397CBF;")
    viewBtn.onclick = viewSerie;
    viewBtn.setAttribute('data-serijaId',serijaId);
    div1 = document.createElement('div');
    div1.setAttribute("class","btn-group bg-dark");
    div1.appendChild(viewBtn);
    let num = document.createElement('small');
    num.innerText=serija.epizode+" epizoda";
    //num.setAttribute("class","card-text");
    div2 = document.createElement('div');
    div2.setAttribute("class","d-flex justify-content-between align-items-center bg-dark");  
    div2.appendChild(div1); 
    div2.appendChild(num);
    div3 = document.createElement('div');
    div3.setAttribute("class","card-body bg-dark");  
    let serieName = document.createElement('h2');
    serieName.innerText=serija.naziv;
    serieName.setAttribute("class","card-text");
    div3.appendChild(serieName);
    div3.appendChild(div2); 
    div4 = document.createElement('div');
    div4.setAttribute("class","card shadow-sm bg-dark");  
    let picture = document.createElement('img');
    picture.setAttribute("src",serija.slika);
    picture.setAttribute("style","width:100%;");
    picture.setAttribute("style","height:225px");
    div4.appendChild(picture); 
    div4.appendChild(div3); 
    div5 = document.createElement('div');
    div5.setAttribute("class","col povecaj");  
    div5.appendChild(div4); 
    let tbody = document.getElementById(tbodyId);
    tbody.appendChild(div5);
    
 

}

function viewSerie(){
    let clickedBtn = this;
   // console.log(clickedBtn);
  
    let serijaId = clickedBtn.getAttribute('data-serijaId');
    window.location.href = 'trenutna.html?id='+ serijaId;
  }


  function getParamValue(name) {
    let location = decodeURI(window.location.toString());
    let index = location.indexOf("?") + 1;
    let subs = location.substring(index, location.length);
    let splitted = subs.split("&");

    for (i = 0; i < splitted.length; i++) {
      let s = splitted[i].split("=");
      let pName = s[0];
      let pValue = s[1];
      if (pName == name) {
        return pValue;
      }
    }
  }